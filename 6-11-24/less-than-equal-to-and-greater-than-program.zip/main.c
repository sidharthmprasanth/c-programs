/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
	int a1,b2;
	printf("enter the fist number:");
	scanf("%d",&a1);
	printf("enter the second number");
	scanf("%d",&b2);
	if(a1>b2)
	{
		printf("nember is greater than%d %d\n",a1,b2);

	}
	else if(a1<b2)
	{
		printf("nember is less than%d %d\n",a1,b2);
	}
	else
	{
		printf("is equal to %d %d",a1,b2);

	}
	return 0;
}
